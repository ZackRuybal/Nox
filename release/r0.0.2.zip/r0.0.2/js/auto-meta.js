$(document).ready(function(){
    $('head').append('<meta charset="UTF-8">');
    $('head').append('<meta content="width=device-width,initial-scale=1" name="viewport">');
});
